function onPageLoaded() {
    // Write your javascript code here
    console.log("page loaded");
}
